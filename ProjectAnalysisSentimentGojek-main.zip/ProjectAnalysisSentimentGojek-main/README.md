# ProjectAnalysisSentimentGojek
Analisis sentimen pengguna aplikasi Gojek menggunakan metode machine learning untuk menentukan apakah ulasan pengguna bersifat positif, negatif, atau netral.

Project Text Mining Kelompok 4 :
1. Nurul Afdhal
2. Oka Maulana
3. Jerry Nurriyansyah
4. Selvia Dela Utari
5. Sabila Mujahidah Al-Khayr
